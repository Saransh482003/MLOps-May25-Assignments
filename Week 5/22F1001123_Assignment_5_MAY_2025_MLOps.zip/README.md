### Files
- **22F1001123_Week_5_code.ipynb** : The code file for the assignment *[.ipynb]*
- **ssh-commands.md** : The codes used in the ssh-in-browser instance *[.ipynb]*
- **data/iris.csv** : The Iris Classification dataset used for model building *[.csv]*

### Objective
To build a basic **Decision Tree Classification** model on the Iris Dataset, using MLFlow to visualise and log the ML Pipeline.

*Assignment Done by: Saransh Saini (22F1001123@ds.study.iitm.ac.in)*
