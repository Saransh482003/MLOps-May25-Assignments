### Files
- **iris_model.py** : Iris model training, and evaluation code *[.py]*
- **test_model.py** : Code for unittesting using pytest *[.py]*
- **.github/workflows/test.yml** : GitHub actions code *[.py]*
- **iris.csv** : The Iris Classification dataset used for model building *[.csv]*
- **requirements.txt** : Contains the libraries to install *[.txt]*

*Assignment Done by: Saransh Saini (22F1001123@ds.study.iitm.ac.in)*
