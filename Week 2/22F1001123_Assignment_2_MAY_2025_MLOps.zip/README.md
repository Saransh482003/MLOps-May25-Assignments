### Files
- **model-training.py** : The code file for the assignment *[.py]*
- **iris.csv** : The Iris Classification dataset used for model building *[.csv]*
- **requirements.txt** : Contains the libraries to install *[.txt]*

*Assignment Done by: Saransh Saini (22F1001123@ds.study.iitm.ac.in)*
