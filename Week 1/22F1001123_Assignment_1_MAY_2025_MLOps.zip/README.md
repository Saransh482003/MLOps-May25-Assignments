### Files
- **22F1001123_Week_1_code.ipynb** : The code file for the assignment *[.ipynb]*
- **data/iris.csv** : The Iris Classification dataset used for model building *[.csv]*

### Objective
To build a basic **Decision Tree Classification** model on the Iris Dataset.

*Assignment Done by: Saransh Saini (22F1001123@ds.study.iitm.ac.in)*
